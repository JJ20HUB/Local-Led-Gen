<?php

if (!defined('ABSPATH')) {
    exit;
}

function local_led_gen_setup(): void
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script']);

    register_nav_menus([
        'primary' => __('Primary Menu', 'local-led-gen'),
    ]);
}
add_action('after_setup_theme', 'local_led_gen_setup');

function local_led_gen_enqueue_assets(): void
{
    $theme_version = wp_get_theme()->get('Version');

    wp_enqueue_style(
        'local-led-gen-theme',
        get_stylesheet_uri(),
        [],
        $theme_version
    );

    $styles_path = get_template_directory() . '/assets/styles.css';
    $styles_ver = file_exists($styles_path) ? (string) filemtime($styles_path) : $theme_version;

    wp_enqueue_style(
        'local-led-gen-styles',
        get_template_directory_uri() . '/assets/styles.css',
        ['local-led-gen-theme'],
        $styles_ver
    );

    $script_path = get_template_directory() . '/assets/script.js';
    $script_ver = file_exists($script_path) ? (string) filemtime($script_path) : $theme_version;

    wp_enqueue_script(
        'local-led-gen-script',
        get_template_directory_uri() . '/assets/script.js',
        [],
        $script_ver,
        true
    );
}
add_action('wp_enqueue_scripts', 'local_led_gen_enqueue_assets');

function local_led_gen_create_pages(): void
{
    $pages = [
        'home'     => 'Home',
        'services' => 'Services',
        'contact'  => 'Contact',
    ];

    $home_id = 0;

    foreach ($pages as $slug => $title) {
        $existing = get_page_by_path($slug, OBJECT, 'page');
        if ($existing) {
            if ($slug === 'home') {
                $home_id = (int) $existing->ID;
            }
            continue;
        }

        $id = wp_insert_post([
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '',
        ]);

        if (!is_wp_error($id) && $slug === 'home') {
            $home_id = $id;
        }
    }

    if ($home_id && (int) get_option('page_on_front') !== $home_id) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_id);
    }
}
add_action('after_switch_theme', 'local_led_gen_create_pages');

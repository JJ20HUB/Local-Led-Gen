<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<footer class="site-footer">
    <div class="container footer-grid">
        <p><strong>Tree Pros Connect</strong><br>Knoxville, Tennessee</p>
        <p><a href="tel:+18653906794">865-390-6794</a><br><a href="mailto:TreeProsConnect@gmail.com">TreeProsConnect@gmail.com</a></p>
        <p><a href="https://g.page/r/Ccs2_3aNAoinEBM/review" target="_blank" rel="noopener noreferrer">Google Business Profile</a></p>
    </div>
    <p class="copyright">&copy; <span id="year"></span> Tree Pros Connect. All rights reserved.</p>
</footer>

<div class="mobile-callbar" aria-label="Mobile call button">
    <a href="tel:+18653906794">Call 865-390-6794</a>
</div>

<?php wp_footer(); ?>
</body>
</html>

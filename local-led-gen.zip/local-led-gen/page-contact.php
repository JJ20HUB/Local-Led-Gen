<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>
<main id="main">
    <section class="page-hero">
        <div class="container">
            <p class="eyebrow">Contact</p>
            <h1>Get a Free Estimate in Knoxville</h1>
            <p class="lead">Call for fastest response, or send us your details and we will follow up quickly.</p>
        </div>
    </section>

    <section class="section section-light">
        <div class="container contact-grid">
            <div class="panel">
                <h2>Call or Email</h2>
                <p><strong>Phone:</strong> <a href="tel:+18653906794">(865) 390-6794</a></p>
                <p><strong>Email:</strong> <a href="mailto:TreeProsConnect@gmail.com">TreeProsConnect@gmail.com</a></p>
                <p><strong>Hours:</strong> Monday-Saturday, 7:00 AM-7:00 PM</p>
                <p><a class="text-link" href="https://www.google.com/search?q=Knoxville+Tree+Proshttps://g.page/r/your-google-business-profilestick=H4sIAAAAAAAA_-NgU1IxqEg0NzNOTTa1ME8xN0pOS7ECiVhYGBhZpJibpaUZmyUnLWIV9s7LryjLzMlJVQgpSk1VCCjKLwYAn7JSqD4AAAAhttps://g.page/r/your-google-business-profilehl=enhttps://g.page/r/your-google-business-profilemat=CXVWA_QCSxJiElcBTVDHntFXCBMSvN3i69n3oEF9tDWKo3dg0-K-hLKmQRqiIXNR-1VsLxidEZepR4wjNPZFQUxF_26_qZFs8L-fcmKwZljoa_3ut0TmDphdwS4uH07RXuIhttps://g.page/r/your-google-business-profileauthuser=1" target="_blank" rel="noopener noreferrer">View Google Business Profile</a></p>
            </div>

            <form class="panel contact-form" action="https://formsubmit.co/TreeProsConnect@gmail.com" method="POST">
                <h2>Request a Quote</h2>
                <input type="hidden" name="_captcha" value="false">
                <input type="hidden" name="_subject" value="New Tree Pros Connect lead">
                <input type="hidden" name="_template" value="table">

                <label for="name">Full Name</label>
                <input id="name" name="name" type="text" required>

                <label for="phone">Phone Number</label>
                <input id="phone" name="phone" type="tel" required>

                <label for="address">Service Address</label>
                <input id="address" name="address" type="text" required>

                <label for="service">Service Needed</label>
                <select id="service" name="service" required>
                    <option value="">Select one</option>
                    <option>Tree Removal</option>
                    <option>Tree Trimming</option>
                    <option>Stump Grinding</option>
                    <option>Storm Cleanup</option>
                    <option>Lot Clearing</option>
                </select>

                <label for="message">Project Details</label>
                <textarea id="message" name="message" rows="5" placeholder="Please share your timeline and any access notes."></textarea>

                <button class="btn btn-primary" type="submit">Send Request</button>
                <p class="small">By submitting this form, you agree to be contacted about your project.</p>
            </form>
        </div>
    </section>
</main>

<?php get_footer(); ?>

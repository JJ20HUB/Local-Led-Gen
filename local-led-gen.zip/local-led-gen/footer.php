<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<footer class="site-footer">
    <div class="container footer-grid">
        <p><strong>Tree Pros Connect</strong><br>Knoxville, Tennessee</p>
        <p><a href="tel:+18653906794">(865) 390-6794</a><br><a href="mailto:TreeProsConnect@gmail.com">TreeProsConnect@gmail.com</a></p>
        <p><a href="https://www.google.com/search?q=Knoxville+Tree+Proshttps://g.page/r/your-google-business-profilestick=H4sIAAAAAAAA_-NgU1IxqEg0NzNOTTa1ME8xN0pOS7ECiVhYGBhZpJibpaUZmyUnLWIV9s7LryjLzMlJVQgpSk1VCCjKLwYAn7JSqD4AAAAhttps://g.page/r/your-google-business-profilehl=enhttps://g.page/r/your-google-business-profilemat=CXVWA_QCSxJiElcBTVDHntFXCBMSvN3i69n3oEF9tDWKo3dg0-K-hLKmQRqiIXNR-1VsLxidEZepR4wjNPZFQUxF_26_qZFs8L-fcmKwZljoa_3ut0TmDphdwS4uH07RXuIhttps://g.page/r/your-google-business-profileauthuser=1" target="_blank" rel="noopener noreferrer">Google Business Profile</a></p>
    </div>
    <p class="copyright">&copy; <span id="year"></span> Tree Pros Connect. All rights reserved.</p>
</footer>

<div class="mobile-callbar" aria-label="Mobile call button">
    <a href="tel:+18653906794">Call (865) 390-6794</a>
</div>

<?php wp_footer(); ?>
</body>
</html>

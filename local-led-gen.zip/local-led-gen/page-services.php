<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>
<main id="main">
    <section class="page-hero">
        <div class="container">
            <p class="eyebrow">Tree Care Services</p>
            <h1>Reliable Tree Work for Homes and Businesses in Knoxville</h1>
            <p class="lead">Every service includes property protection, safe equipment use, and complete debris cleanup.</p>
        </div>
    </section>

    <section class="section section-light">
        <div class="container service-list">
            <article class="service-item">
                <h2>1) Tree Removal</h2>
                <p>For dead, dangerous, or unwanted trees. We evaluate fall zones, rigging needs, and site access before any cut.</p>
            </article>

            <article class="service-item">
                <h2>2) Tree Trimming and Pruning</h2>
                <p>We remove weak or overextended limbs, improve clearance, and shape for long-term tree health.</p>
            </article>

            <article class="service-item">
                <h2>3) Stump Grinding</h2>
                <p>Ground-level and below-grade stump removal to make way for landscaping, sod, or new planting.</p>
            </article>

            <article class="service-item">
                <h2>4) Emergency Storm Cleanup</h2>
                <p>Rapid response for fallen limbs, split trunks, blocked driveways, and urgent hazards after severe weather.</p>
            </article>

            <article class="service-item">
                <h2>5) Lot and Brush Clearing</h2>
                <p>Selective clearing for property preparation while protecting healthy trees you want to keep.</p>
            </article>
        </div>
    </section>

    <section class="section">
        <div class="container split">
            <div class="panel">
                <h3>Why Homeowners Choose Us</h3>
                <ul class="plain-list">
                    <li>Clear communication and transparent estimates</li>
                    <li>Insured crews and professional equipment</li>
                    <li>Respect for lawns, driveways, and structures</li>
                    <li>No high-pressure sales tactics</li>
                </ul>
            </div>
            <div class="panel">
                <h3>Need a Quote?</h3>
                <p>Call now to schedule an estimate in Knoxville or nearby areas.</p>
                <a class="btn btn-primary full" href="tel:+18653906794">Call (865) 390-6794</a>
                <a class="btn btn-outline full" href="<?php echo esc_url(home_url('/contact/')); ?>">Send a Message</a>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>

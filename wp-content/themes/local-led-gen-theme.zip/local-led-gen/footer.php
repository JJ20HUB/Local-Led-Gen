<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<footer class="site-footer">
    <div class="container footer-grid">
        <p><strong>Tree Pros Connect</strong><br>Knoxville, Tennessee</p>
        <p><a href="tel:+18655550147">(865) 555-0147</a><br><a href="mailto:hello@treeprosconnect.com">hello@treeprosconnect.com</a></p>
        <p><a href="https://g.page/r/your-google-business-profile" target="_blank" rel="noopener noreferrer">Google Business Profile</a></p>
    </div>
    <p class="copyright">&copy; <span id="year"></span> Tree Pros Connect. All rights reserved.</p>
</footer>

<div class="mobile-callbar" aria-label="Mobile call button">
    <a href="tel:+18655550147">Call (865) 555-0147</a>
</div>

<?php wp_footer(); ?>
</body>
</html>
